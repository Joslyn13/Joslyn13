import { Component, OnInit } from '@angular/core';
import {BookingService} from '../booking.service';
import { Booking } from './../booking';
import { ActivatedRoute, Router } from '@angular/router';
import { Variable } from './../variable';

@Component({
  selector: 'app-employeebookings',
  templateUrl: './employeebookings.component.html',
  styleUrls: ['./employeebookings.component.css']
})
export class EmployeebookingsComponent implements OnInit {
  tempid:number;
  empid:number;
bookings:Booking;
variable:Variable;


  constructor(private service: BookingService, private router: Router) { }

  ngOnInit(): void {
 
    this.service.getOneBooking(Variable.tempid)
    .subscribe(
      data => {
        this.bookings = data;
        this.empid=data.empid;
        console.log(this.bookings);
      }, error => {
        console.log(error);
      }
      );
   
  }
 
      back()
      {
        this.router.navigate(['/service']);
      }
      logout()
      {
        this.router.navigate(['/login']);
      }
    
}

