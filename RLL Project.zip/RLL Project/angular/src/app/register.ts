

export class Register {
    
    iD:number;
    empid: number;
    name: string;
    phoneno: number;
    department: string;
    address: string;
    password: string;
    
}