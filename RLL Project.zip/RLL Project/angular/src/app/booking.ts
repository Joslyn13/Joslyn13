export class Booking {
   
    empid: number;
    vehicle: string;
    people: string;
    dfrom: string;
    dto: string;
    date1: string;
    time1: string;
    details: string;
  }