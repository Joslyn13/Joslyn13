import { Component, OnInit } from '@angular/core';
import { FeedbackService } from './../feedback.service';
import { Feedback } from '../feedback';
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {


  // form backing object
  feedback:Feedback;
  // message to ui
  message: string;

  // inject service class
  constructor(private service: FeedbackService) { }

  ngOnInit(): void {
    // when page is loaded clear form data
    this.feedback = new Feedback();
  }

  // tslint:disable-next-line: typedef
  createFeedback() {
    if ((this.feedback.name==null )||(this.feedback.empid==null )|| (this.feedback.feedback==null )){
      alert("enter data in all requires feilds");
    }
    else{
    this.service.createFeedback(this.feedback)
    .subscribe(data => {
      this.message = data; // read message
      this.feedback = new Feedback(); // clear form
    }, error => {
      console.log(error);
    });
  }}

}
