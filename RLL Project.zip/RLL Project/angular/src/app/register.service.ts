import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Register } from './register';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  private basePath = 'http://localhost:9040/rest/register';

  constructor(private http: HttpClient) { }


  getAllRegister(): Observable<Register[]> {
    return this.http.get<Register[]>(`${this.basePath}/all`);
  }

  deleteOneRegister(id: number): Observable<any> {
    return this.http.delete(`${this.basePath}/remove/${id}`, {responseType: 'text'});
  }

  createRegister(register: Register): Observable<any> {
    return this.http.post(`${this.basePath}/saves`, register, {responseType: 'text'});
  }

  getOneRegister(empid: number): Observable<Register> {
    return this.http.get<Register>(`${this.basePath}/one/${empid}`);
  }

  updateRegister(id: number, register: Register): Observable<any> {
    return this.http.put(`${this.basePath}/modify/${id}`, register, {responseType : 'text'});
  }

}

