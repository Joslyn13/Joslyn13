package in.companyEmployee.travel.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import in.companyEmployee.travel.model.*;
import in.companyEmployee.travel.service.*;
import in.companyEmployee.travel.util.*;

@RestController
@RequestMapping("/rest/feedback")
@CrossOrigin(origins = "http://localhost:4200")
public class FeedbackRestController {

	private Logger log = LoggerFactory.getLogger(FeedbackRestController.class);

	@Autowired
	private IFeedbackService service;
	@Autowired
	private FeedbackUtil util;

	/**
	 * 1. Read JSON(Student) and convert to Object Format
	 *    Store data in Database. Return one Message.
	 */
	@PostMapping("/feedbacksave")
	public ResponseEntity<String> saveFeedback(
			@RequestBody Feedback feedback)
	{
		log.info("Entered into method with Student data to save");

		ResponseEntity<String> resp = null;
		try {

			log.info("About to call save Operation");

			Integer id = service.saveFeedback(feedback);
			log.debug("Student saved with id "+id);

			String body = "Feedback Success";

			resp =  new ResponseEntity<String>(
					body, 
					HttpStatus.CREATED); //201

			log.info("Sucess response constructed");
		} catch (Exception e) {
			log.error("Unable to save feedback : problem is :"+e.getMessage());
			resp =  new ResponseEntity<String>(
					"Unable to Register Employee", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}

		log.info("About to Exist save method with Response");
		return resp;
	}

	/*
	 * 2. Fetch all rows from database using Service
	 *    Sort data using name, return as JSON, 
	 *    else String message no data found.
	 *    
	 */
	@GetMapping("/feedbackD")
	public ResponseEntity<?> getAllFeedback() {
		log.info("Entered into method to fetch Students data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch employee service");
			List<Feedback> list = service.getAllFeedback();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
				list.sort((s1,s2)->s1.getName().compareTo(s2.getName()));
				/* JDK 1.8
				list = list.stream()
						.sorted((s1,s2)->s1.getName().compareTo(s2.getName()))
						.collect(Collectors.toList());
				 */
				resp = new ResponseEntity<List<Feedback>>(list, HttpStatus.OK);
			} else {
				log.info("No Employee exist: size "+list.size());

				//resp = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Employee Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch employee : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch Employee", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}

}