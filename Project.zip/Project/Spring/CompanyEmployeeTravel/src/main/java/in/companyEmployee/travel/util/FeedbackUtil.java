package in.companyEmployee.travel.util;
import org.springframework.stereotype.Component;
import in.companyEmployee.travel.model.*;



@Component
public class FeedbackUtil {

	public void mapToActualObject(Feedback actual, Feedback feedback) {
		
		actual.setEmpid(feedback.getEmpid());
		actual.setName(feedback.getName());
		actual.setFeedback(feedback.getFeedback());
		
	}

}
