package in.companyEmployee.travel.service.impl;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.companyEmployee.travel.model.*;
import in.companyEmployee.travel.repo.*;
import in.companyEmployee.travel.service.*;



@Service
public class BookingServiceImpl  implements IBookingService  {
	
	@Autowired
	private BookingRepository repo;
	
	@Override
	public Integer saveBooking(Booking s) {
		s = repo.save(s);
		return s.getEmpid();
	}
	@Override
	public void deleteBooking(Integer id) {
		repo.deleteById(id);
	}
	@Override
	public Optional<Booking> getOneBooking(Integer empid) {
		return repo.findById(empid);
	}

	@Override
	public List<Booking> getAllBooking() {
		return repo.findAll();
	}

	@Override
	public boolean isBookingExist(Integer id) {
		return repo.existsById(id);
	}


}


