import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Variable } from './../variable';
import { Register } from './../register';
import { RegisterService } from '../register.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
variable:Variable;
register:Register;
public id:number;
  constructor(private service: RegisterService, private router: Router) { }
  
  ngOnInit(): void {
    this.variable = new Variable();
  }
  newUser()
  {
    this.router.navigate(['/add']);

  }
  Login(){
      
       this.service.getOneRegister(this.variable.empid).subscribe(
         
        data => {
        this.register = data;
        this.check();
        console.log(this.register);
      }, error => {
        console.log(error);
      });
    }
    check()
    {
      if ((this.variable.empid ==this.register.empid && this.variable.password==this.register.password) )
      {
        console.log('11');
      this.router.navigate(['/service']);

    }
    else
    {
      console.log('red');

      alert('Incorrect Login Details');
     
    }
    }
    

}
