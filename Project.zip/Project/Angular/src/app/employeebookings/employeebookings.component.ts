import { Component, OnInit } from '@angular/core';
import {BookingService} from '../booking.service';
import { Booking } from './../booking';
import { ActivatedRoute, Router } from '@angular/router';
import { Variable } from './../variable';

@Component({
  selector: 'app-employeebookings',
  templateUrl: './employeebookings.component.html',
  styleUrls: ['./employeebookings.component.css']
})
export class EmployeebookingsComponent implements OnInit {
  empid:number;
booking:Booking;
variable:Variable;

  constructor(private service: BookingService, private router: Router,private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.getbookings();
   
  }


  getbookings(){
  return this.service.getOneBooking(this.empid).subscribe(
    data => {
    this.booking = data;
    console.log(this.booking);
  }, error => {
    console.log(error);
  });
}
}
