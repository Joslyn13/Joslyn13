import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FeedbackComponent } from './feedback/feedback.component';


import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ServicesComponent } from './services/services.component';
import { AllbookingsComponent } from './allbookings/allbookings.component';
import { AdminComponent } from './admin/admin.component';
import { AllfeedbackComponent } from './allfeedback/allfeedback.component';
import { AllemployeesComponent } from './allemployees/allemployees.component';

import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { EmployeebookingsComponent } from './employeebookings/employeebookings.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    AboutusComponent,
    ServicesComponent,
    AllbookingsComponent,
    FeedbackComponent,
    AdminComponent,
    AllfeedbackComponent,
    AllemployeesComponent,

    AdminloginComponent,
     EmployeebookingsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
