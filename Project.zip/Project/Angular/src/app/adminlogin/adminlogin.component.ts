import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
  name:string;
  password:string;

  constructor(private router:Router) { }

  ngOnInit(): void {
  }
 login()
 {
      if (this.name=='admin'&&this.password=='admin') {
        this.router.navigate(['/admin']);        
      } else {
        alert('Incorrect Login Details');
      }

 }
}
