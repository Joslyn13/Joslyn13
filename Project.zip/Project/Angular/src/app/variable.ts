export class Variable{
    empid:number;
    password: string;
}