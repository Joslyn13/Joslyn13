import { Component, OnInit } from '@angular/core';
import {FeedbackService} from '../feedback.service';
import { Feedback } from './../feedback';
import { Router } from '@angular/router';

@Component({
  selector: 'app-allfeedback',
  templateUrl: './allfeedback.component.html',
  styleUrls: ['./allfeedback.component.css']
})
export class AllfeedbackComponent implements OnInit {
    feedback:Feedback[];
    message: string;
  constructor(private service: FeedbackService, private router: Router) { }

  ngOnInit(): void {
  
  this.getAllFeedback();
}
    getAllFeedback() {
    return this.service.getAllFeedback()
    .subscribe(
      data => {
        this.feedback = data;
      }, error => {
        console.log(error);
      }
    );
  }
  
  allFeedback()
  {
    this.router.navigate(['/allfeedback']);
  }
  allbookings()
  {
    this.router.navigate(['/allbookings']);
  }
  allEmployees()
  {
    this.router.navigate(['/allemployees']);
  }
}