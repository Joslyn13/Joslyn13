package in.companyEmployee.travel.repo;
import org.springframework.data.jpa.repository.JpaRepository;

import in.companyEmployee.travel.model.*;

public interface FeedbackRepository extends JpaRepository<Feedback, Integer>{

}

