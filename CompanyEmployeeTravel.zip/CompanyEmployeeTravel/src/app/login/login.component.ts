import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from '../register/register.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit {

  login = {
    empid: '',
    psw: ''
  };
  showErrorMessage = false;

  constructor(private router: Router, private register: Register) { }

  ngOnInit() {
  }

  authenticateUser() {
    this.register.login(this.login.empid, this.login.psw)
      .subscribe((result) => {
        if (result) {
          this.router.navigateByUrl('register');
        } else {
          this.showErrorMessage = true;
        }
      });
  }

}